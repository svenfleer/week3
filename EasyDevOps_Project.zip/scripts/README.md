# Scripts

Deze map bevat de scripts die gebruikt worden voor het project.
