# EasyDevOps

Deze repository bevat de eerste versie van de EasyDevOps app voor ITM.
